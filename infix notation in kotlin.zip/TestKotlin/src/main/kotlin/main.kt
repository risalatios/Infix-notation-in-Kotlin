import java.time.*

fun main(args: Array<String>) {
    val before = "before"
    val today = "today"
2 days before
    2 days today
call { println("${this}, $it") }

}

infix fun Int.days(string: String) {
    when(string) {
        "before" -> println(LocalDateTime.now().minusDays(this.toLong()).dayOfWeek)
        "today" -> println(LocalDateTime.now().plusDays(this.toLong()).dayOfWeek)
        else -> println("Holiday")
    }
}
// we are adding extension with lamda expression
fun call(greet: String.(String) -> Unit) {
    greet("Hello", "ali")
}
